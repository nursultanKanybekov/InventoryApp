package com.example.chatapp.Notification;

import com.google.firebase.iid.FirebaseInstanceId;


public class MyFirebaseIdService  {

}
