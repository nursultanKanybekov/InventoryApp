# ChatApp
Android Chat App Tutorial With Firebase

This is an imitation of a chatapp project for Android Studio.<br>
My goal of making this app is to learn android studio.

<img src="images/chat.jpg" height="400" width="240" >             <img src="images/Users.jpg" height="400" width="240">             <img src="images/profile.jpg" height="400" width="240">

<img src="images/message.jpg" height="400" width="240">
